
define([
    'js/Widgets/PanelBaseWithHeader'
], function (PanelBaseWithHeader) {

    function TurtleCommandWizard(options) {
        this._panel = new PanelBaseWithHeader();
        this._panel.setTitle('🐢 Turtle Command Wizard');
        this._panel.$body.append(this._renderForm());
    }

    TurtleCommandWizard.prototype._renderForm = function () {
        const container = $('<div></div>');
        container.append(`
            <label>Command:</label>
            <select id="command">
                <option value="Forward">Forward</option>
                <option value="Left">Left</option>
                <option value="Right">Right</option>
                <option value="Width">Width</option>
                <option value="Color">Color</option>
            </select><br/>
            <label>Value:</label>
            <input id="value" type="text" /><br/>
            <button id="add-command">Add Command</button>
        `);

        container.on('click', '#add-command', () => {
            const client = WebGMEGlobal.Client;
            const cmd = $('#command').val();
            const val = $('#value').val();
            const baseId = client.getAllMetaNodes()
                .find(node => client.getNode(node).getAttribute('name') === cmd);

            client.createNode({
                parentId: WebGMEGlobal.State.getActiveObject(),
                baseId,
                attributes: { value: val }
            });
        });

        return container;
    };

    TurtleCommandWizard.prototype.onActivate = function () {};
    TurtleCommandWizard.prototype.onDeactivate = function () {};

    return TurtleCommandWizard;
});
